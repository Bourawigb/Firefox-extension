# Firefox-extension
a firefox extension to  prevent fingerprinting
